int main() {
  return ~5;  //Comentario prueba
}