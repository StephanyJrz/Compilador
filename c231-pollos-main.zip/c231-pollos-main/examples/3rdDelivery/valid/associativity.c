int main() {
    return 1 - 2 - 3;
}