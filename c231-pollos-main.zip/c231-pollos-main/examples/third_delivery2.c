int main() {
  return (6 + 6) / (2 * 3);
}