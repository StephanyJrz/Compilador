int main() {
    return !5;
}