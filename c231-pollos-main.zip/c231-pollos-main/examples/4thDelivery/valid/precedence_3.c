int main() {
    return 2 == 2 > 0;
}