int main() {
    return 0 <= 2;
}