int main() {
    return 2 < 1;
}