int main() {
  return !!7;
}