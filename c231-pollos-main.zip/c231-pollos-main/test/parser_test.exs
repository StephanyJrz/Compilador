defmodule ParserTest do
  use ExUnit.Case
  doctest Parser

  defp create_default_ast(val) do
    %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: nil,
            node_name: :constant,
            right_node: nil,
            value: val
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }
  end

  defp create_default_ast_op(val1, val2, op, type) do
    %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: nil,
              right_node: nil, 
              node_name: :constant,
              value: val1
            },
            right_node: %AST{
              left_node: nil,
              right_node: nil, 
              node_name: :constant,
              value: val2
            },
            node_name: type,
            value: op
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }
  end

  test "comparing ast tree" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast(2)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "a bigger constant value" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast(1000)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "minus operator" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :minus,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: nil,
              node_name: :constant,
              right_node: nil,
              value: 1000
            },
            node_name: :unary_op,
            right_node: nil,
            value: :minus
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "bitwise complement" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :bitwise_complement,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: nil,
              node_name: :constant,
              right_node: nil,
              value: 1000
            },
            node_name: :unary_op,
            right_node: nil,
            value: :bitwise_complement
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "logical minus" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :logical_neg,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: nil,
              node_name: :constant,
              right_node: nil,
              value: 1000
            },
            node_name: :unary_op,
            right_node: nil,
            value: :logical_neg
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "unary operators (minus and bitwise)" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :minus,
      :bitwise_complement,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: %AST{
                left_node: nil,
                node_name: :constant,
                right_node: nil,
                value: 1000
              },
              node_name: :unary_op,
              right_node: nil,
              value: :bitwise_complement
            },
            node_name: :unary_op,
            right_node: nil,
            value: :minus
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "lot of minus" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :minus,
      :minus,
      :minus,
      :minus,
      :minus,
      :minus,
      :minus,
      :minus,
      :minus,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: %AST{
                left_node: %AST{
                  left_node: %AST{
                    left_node: %AST{
                      left_node: %AST{
                        left_node: %AST{
                          left_node: %AST{
                            left_node: %AST{
                              left_node: nil,
                              node_name: :constant,
                              right_node: nil,
                              value: 1000
                            },
                            node_name: :unary_op,
                            right_node: nil,
                            value: :minus
                          },
                          node_name: :unary_op,
                          right_node: nil,
                          value: :minus
                        },
                        node_name: :unary_op,
                        right_node: nil,
                        value: :minus
                      },
                      node_name: :unary_op,
                      right_node: nil,
                      value: :minus
                    },
                    node_name: :unary_op,
                    right_node: nil,
                    value: :minus
                  },
                  node_name: :unary_op,
                  right_node: nil,
                  value: :minus
                },
                node_name: :unary_op,
                right_node: nil,
                value: :minus
              },
              node_name: :unary_op,
              right_node: nil,
              value: :minus
            },
            node_name: :unary_op,
            right_node: nil,
            value: :minus
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "minus and logical minus" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :minus,
      :logical_neg,
      :minus,
      :logical_neg,
      :logical_neg,
      :logical_neg,
      :minus,
      :minus,
      :minus,
      {:constant, 1000},
      :semicolon,
      :close_brace
    ]

    expected_result = %AST{
      left_node: %AST{
        left_node: %AST{
          left_node: %AST{
            left_node: %AST{
              left_node: %AST{
                left_node: %AST{
                  left_node: %AST{
                    left_node: %AST{
                      left_node: %AST{
                        left_node: %AST{
                          left_node: %AST{
                            left_node: %AST{
                              left_node: nil,
                              node_name: :constant,
                              right_node: nil,
                              value: 1000
                            },
                            node_name: :unary_op,
                            right_node: nil,
                            value: :minus
                          },
                          node_name: :unary_op,
                          right_node: nil,
                          value: :minus
                        },
                        node_name: :unary_op,
                        right_node: nil,
                        value: :minus
                      },
                      node_name: :unary_op,
                      right_node: nil,
                      value: :logical_neg
                    },
                    node_name: :unary_op,
                    right_node: nil,
                    value: :logical_neg
                  },
                  node_name: :unary_op,
                  right_node: nil,
                  value: :logical_neg
                },
                node_name: :unary_op,
                right_node: nil,
                value: :minus
              },
              node_name: :unary_op,
              right_node: nil,
              value: :logical_neg
            },
            node_name: :unary_op,
            right_node: nil,
            value: :minus
          },
          node_name: :return,
          right_node: nil,
          value: nil
        },
        node_name: :function,
        right_node: nil,
        value: :main
      },
      node_name: :program,
      right_node: nil,
      value: nil
    }

    assert Parser.parse_program(tokens) == expected_result
  end

  test "addition op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :addition,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :addition, :arit_op)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "minus op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :minus,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :minus, :arit_op)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "multiplication op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :multiplication,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :multiplication,:arit_op)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "division op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :division,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :division,:arit_op)

    assert Parser.parse_program(tokens) == expected_result
  end


test "and op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :and,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :and, :logical)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "or op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :or,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :or, :logical)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "equal op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :equal,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :equal, :equality)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "not equal op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :not_equal,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :not_equal, :equality)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "less than op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :less_than,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :less_than, :relational)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "less than or equal op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :less_than_equal,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :less_than_equal, :relational)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "greater than op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :greater_than,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :greater_than, :relational)

    assert Parser.parse_program(tokens) == expected_result
  end

  test "greater than or equal op" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :greater_than_equal,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = create_default_ast_op(2, 2, :greater_than_equal, :relational)

    assert Parser.parse_program(tokens) == expected_result
  end


  # test to fail
  test "multiple constants" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 1},
      {:constant, 0},
      {:constant, 1},
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: expected ';' before numeric constant"}

    assert Parser.parse_program(tokens) == expected_result
  end

  test "constant value missed" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: expected expression before ';' token"}

    assert Parser.parse_program(tokens) == expected_result
  end

  test "return keyword missed" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      {:constant, 1},
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: return keyword missed"}

    assert Parser.parse_program(tokens) == expected_result
  end

  test "undefined reference to `main'" do
    tokens = [
      :int_keyword,
      :error,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: undefined reference to `main'"}
    assert Parser.parse_program(tokens) == expected_result
  end

  test "minus operator after a constant" do 
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, 2},
      :minus,
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: expected expression before ';' token"}
    assert Parser.parse_program(tokens) == expected_result
  end

  test "minus operator before and after a constant" do
    tokens = [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      :minus,
      {:constant, 2},
      :minus,
      :semicolon,
      :close_brace
    ]

    expected_result = {:error, "Error: expected expression before ';' token"}
    assert Parser.parse_program(tokens) == expected_result
  end
end
