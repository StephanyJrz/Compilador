defmodule NqccTest do
  use ExUnit.Case
  doctest Nqcc

  test "parse arguments - help" do 
    command = ["-h", "examples.c"]

    expected_result = {[help: true], ["examples.c"], []}
    assert Nqcc.parse_args(command) == expected_result
  end

  test "parse arguments - 2 options" do 
    command = ["--source", "-l", "examples.c"]

    expected_result = {[source: true, lexer: true], ["examples.c"], []}
    assert Nqcc.parse_args(command) == expected_result
  end

  test "parse arguments - no filename" do 
    command = ["--all", ""]

    expected_result = {[all: true], [""], []}
    assert Nqcc.parse_args(command) == expected_result
  end

  test "parse arguments - only filename" do 
    command = ["examples.c"]

    expected_result = {[], ["examples.c"], []}
    assert Nqcc.parse_args(command) == expected_result
  end

  test "no spaces between options" do 
    command = ["--source-l", "examples.c"]

    expected_result = {[], [], []}
    assert Nqcc.parse_args(command) == expected_result
  end

end
