defmodule SystemTest do
  use ExUnit.Case

  # ------------------ First delivery ------------------
  # Valid test
  test "spaces" do
    file_path = "examples/1stDelivery/valid/spaces"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "return 2" do
    file_path = "examples/1stDelivery/valid/return_2"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "return 0" do
    file_path = "examples/1stDelivery/valid/return_0"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "no newlines" do
    file_path = "examples/1stDelivery/valid/no_newlines"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "newlines" do
    file_path = "examples/1stDelivery/valid/newlines"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "multi digit" do
    file_path = "examples/1stDelivery/valid/multi_digit"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  # ------------------ Second delivery ------------------
  # Valid test
  test "bitwise" do
    file_path = "examples/2ndDelivery/valid/bitwise"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "neg" do
    file_path = "examples/2ndDelivery/valid/neg"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "nested ops" do
    file_path = "examples/2ndDelivery/valid/nested_ops"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "nested ops 2" do
    file_path = "examples/2ndDelivery/valid/nested_ops_2"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "not five" do
    file_path = "examples/2ndDelivery/valid/not_five"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "not zero" do
    file_path = "examples/2ndDelivery/valid/not_zero"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  # ------------------ Third delivery ------------------
  # Valid test
  test "add" do
    file_path = "examples/3rdDelivery/valid/add"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "associativity" do
    file_path = "examples/3rdDelivery/valid/associativity"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")
          
          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "associativity 2" do
    file_path = "examples/3rdDelivery/valid/associativity_2"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "div neg" do
    file_path = "examples/3rdDelivery/valid/div_neg"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "div" do
    file_path = "examples/3rdDelivery/valid/div"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "mult" do
    file_path = "examples/3rdDelivery/valid/mult"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "parens" do
    file_path = "examples/3rdDelivery/valid/parens"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "precedence" do
    file_path = "examples/3rdDelivery/valid/precedence"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "sub_neg" do
    file_path = "examples/3rdDelivery/valid/sub_neg"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "sub" do
    file_path = "examples/3rdDelivery/valid/sub"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "unop_add" do
    file_path = "examples/3rdDelivery/valid/unop_add"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")
          
          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "unop_parens" do
    file_path = "examples/3rdDelivery/valid/unop_parens"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  #------------------ Fourth delivery ------------------
  # Valid test
  test "and_false" do
    file_path = "examples/4thDelivery/valid/and_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "and_true" do
    file_path = "examples/4thDelivery/valid/and_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "eq_false" do
    file_path = "examples/4thDelivery/valid/eq_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "eq_true" do
    file_path = "examples/4thDelivery/valid/eq_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "ge_false" do
    file_path = "examples/4thDelivery/valid/ge_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "ge_true" do
    file_path = "examples/4thDelivery/valid/ge_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "gt_false" do
    file_path = "examples/4thDelivery/valid/gt_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "gt_true" do
    file_path = "examples/4thDelivery/valid/gt_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "le_false" do
    file_path = "examples/4thDelivery/valid/le_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "le_true" do
    file_path = "examples/4thDelivery/valid/le_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "it_false" do
    file_path = "examples/4thDelivery/valid/lt_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "it_true" do
    file_path = "examples/4thDelivery/valid/lt_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "ne_false" do
    file_path = "examples/4thDelivery/valid/ne_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "ne_true" do
    file_path = "examples/4thDelivery/valid/ne_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")
          
          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "or_false" do
    file_path = "examples/4thDelivery/valid/or_false"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end


  test "or_true" do
    file_path = "examples/4thDelivery/valid/or_true"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "precedence_2" do
    file_path = "examples/4thDelivery/valid/precedence_2"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "precedence_3" do
    file_path = "examples/4thDelivery/valid/precedence_3"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "precedence_4" do
    file_path = "examples/4thDelivery/valid/precedence_4"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")

          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  test "precedence 1" do
    file_path = "examples/4thDelivery/valid/precedence_1"
    Nqcc.main([file_path <> ".c"])

    {expected_result, obtained_result} =
      case :os.type() do
        {:win32, _} ->
          obtained_result = System.cmd(file_path <> ".exe", [])
          System.cmd("gcc", [file_path <> ".c"])
          expected_result = System.cmd("a.exe", [])
          File.rm(file_path <> ".exe")
          
          {expected_result, obtained_result}

        {:unix, :darwin} ->
          {1, 1}

        {:unix, :linux} ->
          {1, 1}
      end

    assert obtained_result == expected_result
  end

  
end