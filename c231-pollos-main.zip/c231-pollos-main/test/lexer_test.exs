defmodule LexerTest do
  use ExUnit.Case
  doctest Lexer

  setup_all do
    {:ok,
     tokens: [
       :int_keyword,
       :main_keyword,
       :open_paren,
       :close_paren,
       :open_brace,
       :return_keyword,
       {:constant, 2},
       :semicolon,
       :close_brace
     ]}
  end

  defp create_tokens_bool_rel_op(val1, val2, op) do
    [
      :int_keyword,
      :main_keyword,
      :open_paren,
      :close_paren,
      :open_brace,
      :return_keyword,
      {:constant, val1},
      op, 
      {:constant, val2},
      :semicolon,
      :close_brace
    ]
  end

  # tests to pass
  test "return 2", state do
    code = """
      int main() {
        return 2;
    }
    """

    s_code = Sanitizer.sanitize_source(code)

    assert Lexer.scan_words(s_code) == state[:tokens]
  end

  test "return 0", state do
    code = """
      int main() {
        return 0;
    }
    """

    s_code = Sanitizer.sanitize_source(code)

    expected_result = List.update_at(state[:tokens], 6, fn _ -> {:constant, 0} end)
    assert Lexer.scan_words(s_code) == expected_result
  end

  test "multi_digit", state do
    code = """
      int main() {
        return 100;
    }
    """

    s_code = Sanitizer.sanitize_source(code)

    expected_result = List.update_at(state[:tokens], 6, fn _ -> {:constant, 100} end)
    assert Lexer.scan_words(s_code) == expected_result
  end

  test "new_lines", state do
    code = """
    int
    main
    (
    )
    {
    return
    2
    ;
    }
    """

    s_code = Sanitizer.sanitize_source(code)

    assert Lexer.scan_words(s_code) == state[:tokens]
  end

  test "no_newlines", state do
    code = """
    int main(){return 2;}
    """

    s_code = Sanitizer.sanitize_source(code)

    assert Lexer.scan_words(s_code) == state[:tokens]
  end

  test "spaces", state do
    code = """
    int   main    (  )  {   return  2 ; }
    """

    s_code = Sanitizer.sanitize_source(code)

    assert Lexer.scan_words(s_code) == state[:tokens]
  end

  test "elements separated just by spaces", state do
    assert Lexer.scan_words(["int", "main(){return", "2;}"]) == state[:tokens]
  end

  test "function name separated of function body", state do
    assert Lexer.scan_words(["int", "main()", "{return", "2;}"]) == state[:tokens]
  end

  test "everything is separated", state do
    assert Lexer.scan_words(["int", "main", "(", ")", "{", "return", "2", ";", "}"]) ==
             state[:tokens]
  end

  test "minus operator", state do
    words = ["int", "main()", "{", "return", "-2;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :minus)

    assert Lexer.scan_words(words) == expected_result
  end

  test "bitwise complement operator", state do
    words = ["int", "main()", "{", "return", "~2;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :bitwise_complement)

    assert Lexer.scan_words(words) == expected_result
  end

  test "logical minus operator", state do
    words = ["int", "main()", "{", "return", "!2;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :logical_neg)

    assert Lexer.scan_words(words) == expected_result
  end

  test "two operators", state do
    words = ["int", "main(){", "return", "!~2;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :logical_neg)
    expected_result = List.insert_at(expected_result, 7, :bitwise_complement)

    assert Lexer.scan_words(words) == expected_result
  end

  test "three operators", state do
    words = ["int", "main(){", "return", "!~-2;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :logical_neg)
    expected_result = List.insert_at(expected_result, 7, :bitwise_complement)
    expected_result = List.insert_at(expected_result, 8, :minus)

    assert Lexer.scan_words(words) == expected_result
  end

  test "addition", state do
    words = ["int", "main(){", "return", "2+2;", "}"]

    expected_result = List.insert_at(state[:tokens], 7, :addition)
    expected_result = List.insert_at(expected_result, 8, {:constant, 2})

    assert Lexer.scan_words(words) == expected_result
  end

  test "minus", state do
    words = ["int", "main(){", "return", "2-5;", "}"]

    expected_result = List.insert_at(state[:tokens], 7, :minus)
    expected_result = List.insert_at(expected_result, 8, {:constant, 5})

    assert Lexer.scan_words(words) == expected_result
  end

  test "multiplication", state do
    words = ["int", "main(){", "return", "2*5;", "}"]

    expected_result = List.insert_at(state[:tokens], 7, :multiplication)
    expected_result = List.insert_at(expected_result, 8, {:constant, 5})

    assert Lexer.scan_words(words) == expected_result
  end

  test "division", state do
    words = ["int", "main(){", "return", "2/5;", "}"]

    expected_result = List.insert_at(state[:tokens], 7, :division)
    expected_result = List.insert_at(expected_result, 8, {:constant, 5})

    assert Lexer.scan_words(words) == expected_result
  end

  test "multiple operation", state do
    words = ["int", "main(){", "return", "-2", "+", "2", "*", "3;", "}"]

    expected_result = List.insert_at(state[:tokens], 6, :minus)
    expected_result = List.insert_at(expected_result, 8, :addition)
    expected_result = List.insert_at(expected_result, 9, {:constant, 2})
    expected_result = List.insert_at(expected_result, 10, :multiplication)
    expected_result = List.insert_at(expected_result, 11, {:constant, 3})

    assert Lexer.scan_words(words) == expected_result
  end

  #create_tokens_bool_rel_op(val1, val2, op)
  test "and" do
    words = ["int", "main(){", "return", "0", "&&", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(0, 3, :and)

    assert Lexer.scan_words(words) == expected_result
  end

  test "or" do
    words = ["int", "main(){", "return", "0", "||", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(0, 3, :or)

    assert Lexer.scan_words(words) == expected_result
  end

  test "equal" do
    words = ["int", "main(){", "return", "3", "==", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(3, 3, :equal)

    assert Lexer.scan_words(words) == expected_result
  end

  test "not equal" do
    words = ["int", "main(){", "return", "0", "!=", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(0, 3, :not_equal)

    assert Lexer.scan_words(words) == expected_result
  end

  test "less than" do
    words = ["int", "main(){", "return", "5", "<", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(5, 3, :less_than)

    assert Lexer.scan_words(words) == expected_result
  end

  test "less than or equal" do
    words = ["int", "main(){", "return", "6", "<=", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(6, 3, :less_than_equal)

    assert Lexer.scan_words(words) == expected_result
  end

  test "greater than" do
    words = ["int", "main(){", "return", "6", ">", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(6, 3, :greater_than)

    assert Lexer.scan_words(words) == expected_result
  end

  test "greater than or equal" do
    words = ["int", "main(){", "return", "6", ">=", "3;", "}"]

    expected_result = create_tokens_bool_rel_op(6, 3, :greater_than_equal)

    assert Lexer.scan_words(words) == expected_result
  end

  # tests to fail
  test "wrong case", state do
    words = ["int", "main()", "{", "RETURN", "2;", "}"]

    expected_result = List.update_at(state[:tokens], 5, fn _ -> {:error, "RETURN"} end)
    assert Lexer.scan_words(words) == expected_result
  end

  test "c is case sensitive - int", state do
    words = ["INT", "main()", "{", "return", "2;", "}"]

    expected_result = List.update_at(state[:tokens], 0, fn _ -> {:error, "INT"} end)
    assert Lexer.scan_words(words) == expected_result
  end

  test "c is case sensitive - all keywords", state do
    words = ["INT", "main()", "{", "RETURN", "2;", "}"]

    expected_result = List.update_at(state[:tokens], 0, fn _ -> {:error, "INT"} end)
    expected_result = List.update_at(expected_result, 5, fn _ -> {:error, "RETURN"} end)

    assert Lexer.scan_words(words) == expected_result
  end
end
