defmodule SanitizerTest do
  use ExUnit.Case
  doctest Sanitizer

  test "sanitize c program" do
    code = """
      int main() {
      return 2;
    }
    """

    expected_result = ["int", "main()", "{", "return", "2;", "}"]
    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize any text" do
    text = """

    Hola mi nombre es   Erick
      y este es mi primer dia en

    la facultad de

    ingenieria
    """

    expected_result = ["Hola", "mi", "nombre", "es", "Erick", "y", "este", "es", "mi",
    "primer", "dia", "en", "la", "facultad", "de", "ingenieria"]

    assert Sanitizer.sanitize_source(text) == expected_result
  end

  test "sanitize c program in different lines" do
    code = """
    int
    main
    (
    )
    {
    return
    2
    ;
    }
    """

    expected_result = ["int", "main", "(", ")", "{", "return", "2", ";", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize minus operator" do
    code = """
      int main() {
        return -5;
      }
    """

    expected_result = ["int", "main()", "{", "return", "-5;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize bitwise complement operator" do
    code = """
      int main() {
        return ~5;
      }
    """

    expected_result = ["int", "main()", "{", "return", "~5;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize logical negation operator" do
    code = """
      int main() {
        return !5;
      }
    """

    expected_result = ["int", "main()", "{", "return", "!5;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize addition operation" do
    code = """
      int main() {
        return 5+5;
      }
    """

    expected_result = ["int", "main()", "{", "return", "5+5;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize minus operation" do
    code = """
      int main() {
        return 5 - 5 ;
      }
    """

    expected_result = ["int", "main()", "{", "return", "5", "-", "5", ";", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize multiplication operation" do
    code = """
      int main() {
        return 5* 3;
      }
    """

    expected_result = ["int", "main()", "{", "return", "5*", "3;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  test "sanitize division operation" do
    code = """
      int main() {
        return 5/5;
      }
    """

    expected_result = ["int", "main()", "{", "return", "5/5;", "}"]

    assert Sanitizer.sanitize_source(code) == expected_result
  end

  #test to fail
  test "sanitizer does not remove spaces between" do
    code = """
    int main() {
      return 2;
    }
    """

    expected_result = ["intmain(){return2;}"]
    refute Sanitizer.sanitize_source(code) == expected_result
  end
end
