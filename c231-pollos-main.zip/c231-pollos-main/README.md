# Nqcc - team 'c231-pollos'

**C compiler project written with Elixir**

## 4th Delivery 

To see first delivery, go [here](https://github.com/hiphoox/c231-pollos/tree/delivery-1).
To see second delivery, go [here](https://github.com/hiphoox/c231-pollos/tree/delivery-2).
To see third delivery, go [here](https://github.com/hiphoox/c231-pollos/tree/delivery-3).

In this release, our compiler can handle manage  boolean and relational operators (more binary operators)!

Boolean operators: 
- __Logical AND (&&)__ : 1 && 1 = TRUE
- __Logical OR (||)__ : 1 || 0 = TRUE


Relational operators: 
- __Equal to (==)__ : 5 == 3 = FALSE
- __Not Equal to (!=)__ : 5 != 3 = TRUE
- __Less than (<)__ : 5 < 3 = FALSE
- __Less than or equal to (<=)__:5 <= 5 = TRUE
- __Greater than (>)__:5 > 3 = TRUE
- __Greater than or equal to (>=)__:5 >= 8 = FALSE

Examples: 
```
int main() {
    return 1 || 0 && 2;
}

int main() {
    return 2 == 2 > 0;
}
```

## Installation

1. git clone git@github.com:hiphoox/c231-pollos.git
2. cd qncc
3. mix escript.build

## Using for Mac

- nqcc file_name.c
- nqcc --help

## Using for Linux

- ./nqcc file_name.c
- ./nqcc --help

## Using for Windows

- escript nqcc file_name.c
- escript nqcc --help

**NOTE: In windows we use the command 'escript' because the file is compiled in the elixir virtual machine and it is not a native windows executable**

## Examples
- $ nqcc ./examples/return_2.c

### Members

- Fuerte Martinez Nestor Enrique
- Juárez Gallegos Stephany Anali
- Pérez Pérez Alberto Guadalupe
- Vazquez Sanchez Erick Alejandro

### Instructor
- Ing. Norberto Jesus Ortigoza Marquez. 