defmodule Lexer do
  @moduledoc """
  Modulo encargado de generar una lista de tokens
  de las instrucciones en c.
  """

  @doc """
  Devuelve una lista de tokens
  """
  def scan_words(words) do
    Enum.flat_map(words, &lex_raw_tokens/1)
  end

  def get_constant(program) do
    case Regex.run(~r/^\d+/, program) do
      [value] ->
        {{:constant, String.to_integer(value)}, String.trim_leading(program, value)}

      nil ->
        {:error, program}
    end
  end

  @doc """
  Funcion recursiva que recorre las instrucciones y le asigna su
  respectivo token.
  """
  def lex_raw_tokens(program) when program != "" do
    {token, rest} =
      case program do
        "{" <> rest ->
          {:open_brace, rest}

        "}" <> rest ->
          {:close_brace, rest}

        "(" <> rest ->
          {:open_paren, rest}

        ")" <> rest ->
          {:close_paren, rest}

        ";" <> rest ->
          {:semicolon, rest}

        "return" <> rest ->
          {:return_keyword, rest}

        "int" <> rest ->
          {:int_keyword, rest}

        "main" <> rest ->
          {:main_keyword, rest}

        "&&" <> rest ->
          { :and, rest }

        "||" <> rest ->
          { :or, rest }

        "==" <> rest ->
          { :equal, rest }

        "!=" <> rest ->
          { :not_equal, rest }

        "<=" <> rest ->
          { :less_than_equal, rest }

        "<" <> rest ->
          { :less_than, rest }

        ">=" <> rest ->
          { :greater_than_equal, rest }

        ">" <> rest ->
          { :greater_than, rest }

        "~" <> rest ->
          {:bitwise_complement, rest}

        "!" <> rest ->
          {:logical_neg, rest}

        "-" <> rest ->
          {:minus, rest}

        "+" <> rest ->
          {:addition, rest}

        "*" <> rest ->
          {:multiplication, rest}

        "/" <> rest ->
          {:division, rest}

        rest ->
          get_constant(rest)

      end


    if token != :error do
      remaining_tokens = lex_raw_tokens(rest)
      [token | remaining_tokens]
    else
      [{:error, rest}]
    end
  end

  def lex_raw_tokens(_program) do
    []
  end
end