defmodule CodeGenerator do
  @moduledoc """
  Modulo encargado de generar el codigo en ensamblador
  para el archivo c.
  """

  defp get_os(), do: :os.type()

  def generate_code(ast) do
    pid = spawn(Counter, :counter, [])
    assembler = post_order(ast, pid)
    send(pid, :stop)
    assembler
  end

  @doc """
  Recorre el AST en postorder y acorde al valor de cada nodo
  genera codigo en ensamblador
  """
  def post_order(node, pid) do
    case node do
      nil ->
        nil

      ast_node ->
        code_snippet_l = post_order(ast_node.left_node, pid)
        code_snippet_r = post_order(ast_node.right_node, pid)

        if code_snippet_r do
          emit_code(ast_node.node_name, code_snippet_l, code_snippet_r, ast_node.value, pid)
        else
          emit_code(ast_node.node_name, code_snippet_l, ast_node.value)
        end
    end
  end

  def emit_code(:program, code_snippet, _) do
    case get_os() do
      {:win32, _} ->
        """
          .text
        """

      {:unix, :darwin} ->
        """
          .section        __TEXT,__text,regular,pure_instructions
          .p2align        4, 0x90
        """

      {:unix, :linux} ->
        """
          .text
        """
    end <>
      code_snippet
  end

  def emit_code(:function, code_snippet, :main) do
    case get_os() do
      {:win32, _} ->
        """
          .globl  _main
        _main:                    ## @main
        """

      {:unix, :darwin} ->
        """
            .globl  _main         ## -- Begin function main
        _main:                    ## @main
        """

      {:unix, :linux} ->
        """
          .globl	main
          .type	main, @function
        main:
        """
    end <>
      code_snippet
  end

  def emit_code(:return, code_snippet, _) do
    """
      #{code_snippet}
      ret
    """
  end

  def emit_code(:unary_op, code_snippet, value) do
    code_snippet <>
      case value do
        :minus ->
          """

            neg %eax
          """

        :bitwise_complement ->
          """

            not %eax
          """

        :logical_neg ->
          """

            cmp $0, %eax
            mov $0, %eax
            sete %al
          """
      end
  end

  def emit_code(:constant, _code_snippet, value) do
    "mov $#{value}, %eax"
  end

  def emit_code(:arit_op, code_snippet_l, code_snippet_r, value, _) do
    """
      #{code_snippet_l}
      push %eax
      #{code_snippet_r}
      mov %eax, %ecx
      pop %eax
    """ <>
      case value do
        :addition ->
          """
            add %ecx, %eax
          """

        :minus ->
          """
            sub %ecx, %eax
          """

        :multiplication ->
          """
            mul %ecx
          """

        :division ->
          """
            xor %edx, %edx
            cdq
            idiv %ecx
          """
      end
  end

  def emit_code(:logical, code_snippet_l, code_snippet_r, value, pid) do
    send(pid, {:get, self()})
  
    counter_val =
      receive do
        val -> val
      end
  
    send(pid, :inc)
  
    case value do
      :or ->
        """
          #{code_snippet_l}
          cmpl $0, %eax
          je _or_#{counter_val}
          movl $1, %eax
          jmp _end_or_#{counter_val}
        _or_#{counter_val}:
          #{code_snippet_r}
          cmpl $0, %eax
          movl $0, %eax
          setne %al
        _end_or_#{counter_val}:
        """
  
      :and ->
        """
          #{code_snippet_l}
          cmpl $0, %eax 
          jne _and_#{counter_val} 
          jmp _end_and_#{counter_val}
        _and_#{counter_val}:
          #{code_snippet_r}
          cmpl $0, %eax 
          movl $0, %eax
          setne %al
        _end_and_#{counter_val}:
        """
    end
  end

  def emit_code(:equality, code_snippet_l, code_snippet_r, value, _) do
    """
      #{code_snippet_l}
      push   %eax          
      #{code_snippet_r}
      pop    %ecx          
      cmpl   %eax, %ecx    
      movl   $0, %eax      
    """ <>
      case value do
        :equal ->
          """
            sete %al           
          """
  
        :not_equal ->
          """
            setne %al
          """
      end
  end
  
  def emit_code(:relational, code_snippet_l, code_snippet_r, value, _) do
    """
      #{code_snippet_l}
      push   %eax          
      #{code_snippet_r}
      pop    %ecx          
      cmpl   %eax, %ecx    
      movl   $0, %eax      
    """ <>
      case value do
        :less_than ->
          """
            setl %al
          """
  
        :less_than_equal ->
          """
            setle %al
          """
  
        :greater_than ->
          """
            setg %al
          """
  
        :greater_than_equal ->
          """
            setge %al
          """
      end
  end
end