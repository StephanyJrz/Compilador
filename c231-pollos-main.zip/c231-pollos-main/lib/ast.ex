defmodule AST do
  defstruct [:node_name, :value, :left_node, :right_node]
end
