defmodule Nqcc do
  @moduledoc """
  Modulo principal del programa
  """

  @commands %{
    "help" => "Prints this help",
    "all" => "Prints the entire compilation process",
    "lexer" => "Prints the lexer output",
    "parser" => "Prints the parser output",
    "source" => "Prints the content of the source program"
  }

  def main(args) do
    args
    |> parse_args
    |> process_args
  end

  @doc """
  De los argumentos enviados desde terminal
  revisa si alguno esta definido y en caso
  de coincidir establece el valor definido
  """
  def parse_args(args) do
    OptionParser.parse(args,
      switches: [
        help:   :boolean,
        all:    :boolean,
        lexer:  :boolean,
        parser: :boolean,
        source: :boolean
      ],
      aliases: [
        h: :help,
        a: :all,
        l: :lexer,
        p: :parser,
        s: :source
      ]
    )
  end


  defp process_args({[], [], []}) do
    print_help_message()
  end


  defp process_args({_, [], _}) do
    print_help_message()
  end

  defp process_args(args_parsed) do

    {flags, [file_name], _} = args_parsed

    cond do
      List.keyfind(flags, :help, 0) ->
        print_help_message()

      flags == []->
        compile_file(file_name)

      List.keyfind(flags, :all, 0) ->
        compile_file(file_name, all: true)

      true ->
        compile_file(file_name, flags)

    end
  end

  defp compile_file(file_path) do
    IO.puts("Compiling file: " <> file_path)
    assembly_path = String.replace_trailing(file_path, ".c", ".s")
    
    try do
      PreProcessor.pre_process_program(file_path)
      |> Sanitizer.sanitize_source()
      |> Lexer.scan_words()
      |> ErrorHandler.lexer_handler()
      |> Parser.parse_program()
      |> ErrorHandler.parser_handler()
      |> CodeGenerator.generate_code()
      |> Linker.generate_binary(assembly_path)
    rescue 
      e -> IO.puts(e.message)
    end
  end

  defp compile_file(file_path, all: true) do
    IO.puts("Compiling file: " <> file_path)
    assembly_path = String.replace_trailing(file_path, ".c", ".s")
    
    try do 
      PreProcessor.pre_process_program(file_path)
      |> Sanitizer.sanitize_source()
      |> PrettyPrint.print_list("\nSanitizer ouput")
      |> Lexer.scan_words()
      |> ErrorHandler.lexer_handler()
      |> PrettyPrint.print_list("\nLexer ouput")
      |> Parser.parse_program()
      |> ErrorHandler.parser_handler()
      |> PrettyPrint.print_ast("\nParser ouput:")
      |> CodeGenerator.generate_code()
      |> PrettyPrint.print_text("\nCode Generator output:")
      |> Linker.generate_binary(assembly_path)
    rescue
      e -> IO.puts(e.message)
    end
  end

  defp compile_file(file_path, flags) do
    IO.puts("Compiling file: " <> file_path)
    assembly_path = String.replace_trailing(file_path, ".c", ".s")
    
    try do
      lexer_output = PreProcessor.pre_process_program(file_path)
      |> Sanitizer.sanitize_source()
      |> Lexer.scan_words()
      |> ErrorHandler.lexer_handler()

      if List.keyfind(flags, :lexer, 0) do
        PrettyPrint.print_list(lexer_output, "\nLexer output")
      end

      parser_output = Parser.parse_program(lexer_output)
      |> ErrorHandler.parser_handler()

      if List.keyfind(flags, :parser, 0) do
        PrettyPrint.print_ast(parser_output, "\nParser output:")
      end

      code_generator_output = CodeGenerator.generate_code(parser_output)

      if List.keyfind(flags, :source, 0) do
        PrettyPrint.print_text(code_generator_output, "\nCode Generator output:")
      end


      Linker.generate_binary(code_generator_output, assembly_path)
    rescue 
      e -> IO.puts(e.message)
    end
  end

  defp print_help_message do


    msg = """
    nqcc --option file_name

    options: --help -h, --all -a, --lexer -l, --parser -p, --source -s

    The compiler supports following options:
    """

    IO.puts(msg)

    @commands
    |> Enum.map(fn {command, description} -> IO.puts("  #{command} - #{description}") end)
  end
end
