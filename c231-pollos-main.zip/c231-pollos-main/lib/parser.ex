defmodule Parser do
  @moduledoc """
  En este modulo se revisa que la sintaxis del programa este correcta
  al revisar la estructura del programa con los tokens ingresados
  """

  def parse_program(token_list) do
    function = parse_function(token_list)

    case function do
      {{:error, error_message}, _rest} ->
        {:error, error_message}

      {function_node, rest} ->
        if rest == [] do
          %AST{node_name: :program, left_node: function_node}
        else
          {:error, "Error: there are more elements after function end"}
        end
    end
  end

  def parse_function([next_token | rest]) do
    if next_token == :int_keyword do
      [next_token | rest] = rest

      if next_token == :main_keyword do
        [next_token | rest] = rest

        if next_token == :open_paren do
          [next_token | rest] = rest

          if next_token == :close_paren do
            [next_token | rest] = rest

            if next_token == :open_brace do
              statement = parse_statement(rest)

              case statement do
                {{:error, error_message}, rest} ->
                  {{:error, error_message}, rest}

                {statement_node, [next_token | rest]} ->
                  if next_token == :close_brace do
                    {%AST{node_name: :function, value: :main, left_node: statement_node}, rest}
                  else
                    {{:error, "Error: close brace missed"}, rest}
                  end
              end
            else
              {{:error, "Error: open brace missed"}, rest}
            end
          else
            {{:error, "Error: close parentesis missed"}, rest}
          end
        else
          {{:error, "Error: open parentesis missed"}, rest}
        end
      else
        {{:error, "Error: undefined reference to `main'"}, rest}
      end
    else
      {{:error, "Error: return type value missed"}, rest}
    end
  end

  def parse_statement([next_token | rest]) do
    if next_token == :return_keyword do
      expression = parse_expression(rest)

      case expression do
        {{:error, error_message}, rest} ->
          {{:error, error_message}, rest}

        {exp_node, [next_token | rest]} ->
          if next_token == :semicolon do
            {%AST{node_name: :return, left_node: exp_node}, rest}
          else
            case next_token do
              {:constant, _} ->
                {{:error,
                  "Error: expected '#{Tokens.get_token_value(:semicolon)}' before numeric constant"},
                 rest}

              _ ->
                {{:error,
                  "Error: expected '#{Tokens.get_token_value(:semicolon)}' after expression before '#{
                    Tokens.get_token_value(next_token)
                  }' token"}, rest}
            end
          end
      end
    else
      {{:error, "Error: return keyword missed"}, rest}
    end
  end


  def parse_expression(token_list) do
    log_and_exp = parse_logical_and_exp(token_list)

    case log_and_exp do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        expression_rep(log_and_exp)
    end
  end

  def expression_rep(val) do
    {node, [next_token | rest]} = val

    cond do
      next_token != :or ->
        val

      true ->
        next_log_and_exp = parse_logical_and_exp(rest)

        case next_log_and_exp do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_log_and_exp_node, rest} ->
            {%AST{
               node_name: :logical,
               value: next_token,
               left_node: node,
               right_node: next_log_and_exp_node
             }, rest}
            |> expression_rep()
        end
    end
  end


  def parse_logical_and_exp(token_list) do
    eq_exp = parse_equality_exp(token_list)

    case eq_exp do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        log_and_rep(eq_exp)
    end
  end

  def log_and_rep(val) do
    {node, [next_token | rest]} = val

    cond do
      next_token != :and ->
        val

      true ->
        next_eq_exp = parse_equality_exp(rest)

        case next_eq_exp do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_eq_exp_node, rest} ->
            {%AST{
               node_name: :logical,
               value: next_token,
               left_node: node,
               right_node: next_eq_exp_node
             }, rest}
            |> log_and_rep()
        end
    end
  end

  def parse_equality_exp(token_list) do
    rel_exp = parse_relational_exp(token_list)

    case rel_exp do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        equality_rep(rel_exp)
    end
  end

  def equality_rep(val) do
    {node, [next_token | rest]} = val

    cond do
      next_token != :equal and next_token != :not_equal ->
        val

      true ->
        next_rel_exp = parse_relational_exp(rest)

        case next_rel_exp do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_rel_exp_node, rest} ->
            {%AST{
               node_name: :equality,
               value: next_token,
               left_node: node,
               right_node: next_rel_exp_node
             }, rest}
            |> equality_rep()
        end
    end
  end

  def parse_relational_exp(token_list) do
    add_exp = parse_additive_exp(token_list)

    case add_exp do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        relational_rep(add_exp)
    end
  end

  def relational_rep(val) do
    {node, [next_token | rest]} = val

    cond do
      next_token != :less_than and next_token != :less_than_equal and next_token != :greater_than and
          next_token != :greater_than_equal ->
        val

      true ->
        next_add_exp = parse_additive_exp(rest)

        case next_add_exp do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_add_exp_node, rest} ->
            {%AST{
               node_name: :relational,
               value: next_token,
               left_node: node,
               right_node: next_add_exp_node
             }, rest}
            |> relational_rep()
        end
    end
  end

  def parse_additive_exp(token_list) do
    term = parse_term(token_list)

    case term do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        add_rep(term)
    end
  end

  def add_rep(term) do
    {term_node, [next_token | rest]} = term

    cond do
      next_token != :addition and next_token != :minus ->
        term

      true ->
        next_term = parse_term(rest)

        case next_term do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_term_node, rest} ->
            {%AST{
               node_name: :arit_op,
               value: next_token,
               left_node: term_node,
               right_node: next_term_node
             }, rest}
            |> add_rep()
        end
    end
  end

  def parse_term(token_list) do
    factor = parse_factor(token_list)

    case factor do
      {{:error, error_msg}, rest} ->
        {{:error, error_msg}, rest}

      _ ->
        term_rep(factor)
    end
  end

  def term_rep(factor) do
    {factor_node, [next_token | rest]} = factor

    cond do
      next_token != :multiplication and next_token != :division ->
        factor

      true ->
        next_factor = parse_factor(rest)

        case next_factor do
          {{:error, error_msg}, rest} ->
            {{:error, error_msg}, rest}

          {next_factor_node, rest} ->
            {%AST{
               node_name: :arit_op,
               value: next_token,
               left_node: factor_node,
               right_node: next_factor_node
             }, rest}
            |> term_rep()
        end
    end
  end

  def parse_factor([next_token | rest]) do
    cond do
      next_token == :open_paren ->
        expression = parse_expression(rest)

        case expression do
          {{:error, error_message}, rest} ->
            {{:error, error_message}, rest}

          {exp_node, [next_token | rest]} ->
            if next_token == :close_paren do
              {exp_node, rest}
            else
              {{:error,
                "Error: expected '#{Tokens.get_token_value(:close_paren)}' before '#{
                  Tokens.get_token_value(next_token)
                }' token"}, rest}
            end
        end

      next_token == :minus || next_token == :bitwise_complement || next_token == :logical_neg ->
        factor = parse_factor(rest)

        case factor do
          {{:error, error_message}, rest} ->
            {{:error, error_message}, rest}

          {factor_node, rest} ->
            {%AST{node_name: :unary_op, value: next_token, left_node: factor_node}, rest}
        end

      true ->
        case next_token do
          {:constant, value} ->
            {%AST{node_name: :constant, value: value}, rest}

          _ ->
            {{:error,
              "Error: expected expression before '#{Tokens.get_token_value(next_token)}' token"},
             rest}
        end
    end
  end
end
