defmodule ErrorHandler do
  def lexer_handler(tokens) do
    res =
      Enum.find(tokens, fn x ->
        if is_tuple(x) == true do
          elem(x, 0) == :error
        end
      end)

    case res do
      nil ->
        tokens

      {:error, msg} ->
        raise """
        Error: invalid token 
          #{msg} 
          ^     
        """
    end
  end

  def parser_handler(parser_output) do
    cond do
      is_tuple(parser_output) -> raise "\n" <> elem(parser_output, 1) <> "\n"
      true -> parser_output
    end
  end
end