defmodule Counter do

  def counter(), do: counter(0)

  defp counter(val) do
    new_val = 
      receive do
        {:get, pid} ->
          send(pid, val)

        :inc ->
          val + 1

        :stop ->
          nil
      end
    
    if new_val != nil, do: counter(new_val)
  end
end