defmodule PrettyPrint do
  def print_text(text, title) do
    IO.puts(title <> "\n\n" <> text)
    text
  end

  def print_list(list, title) do
    IO.inspect(list, label: title)
  end

  def print_ast(ast, title) do
    IO.puts(title <> "\n")
    pre_order(ast, 0)

    ast
  end

  defp pre_order(node, iden) do
    case node do
      nil ->
        nil

      ast_node ->
        print_node(ast_node, iden)

        pre_order(ast_node.left_node, iden + 1)
        pre_order(ast_node.right_node, iden + 1)
    end
  end

  defp print_node(node, val) do
    ident = String.duplicate("\t", val)

    IO.puts("""
    #{ident} |>  Name:   #{node.node_name} 
    #{ident} |   Value:  #{node.value}
    """)
  end
end