defmodule Tokens do
  defp get_tokens_map() do
    %{
      open_brace:           "{",
      close_brace:          "}",
      open_paren:           "(",
      close_paren:          ")",
      semicolon:            ";",
      return_keyword:       "return",
      int_keyword:          "int",
      main_keyword:         "main",
      minus:                "-",
      bitwise_complement:   "~",
      logical_neg:          "!",
      addition:             "+",
      multiplication:       "*",
      division:             "/",
      and:                  "&&",
      or:                   "||",
      equal:                "==",
      not_equal:            "!=",
      less_than_equal:      "<=",
      less_than:            "<",
      greater_than_equal:   ">=",
      greater_than:         ">",
    }
  end

  def get_token_value(key) do
    tokens = get_tokens_map()
    tokens[key]
  end
end