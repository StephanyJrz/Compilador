defmodule PreProcessor do 
    def pre_process_program( path ) do 
        File.stream!( path )
        |> Stream.map( &detect_comments/1 )
        |> Enum.join("\n")
    end
  
  
    defp detect_comments( line )do 
      if String.contains?( line, "//" ) do 
        [ head | _tail ] =
          String.split( line, "//" )
        head
      else 
        line
      end
    end
  end