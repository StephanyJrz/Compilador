defmodule Sanitizer do
  @moduledoc """
  Modulo encargado de limpiar las entradas de los modulos
  """

  @doc """
  Limpia el texto proviniente de un archivo, borrando
  los espacios al inicio y al final del texto y crea
  una lista con las palabras que se encuentren separadas
  con un espacio. 
  """
  def sanitize_source(file_content) do
    trimmed_content = String.trim(file_content)
    Regex.split(~r/\s+/, trimmed_content)
  end
end
